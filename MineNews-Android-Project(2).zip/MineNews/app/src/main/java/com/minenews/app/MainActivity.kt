package com.minenews.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Xml
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import org.xmlpull.v1.XmlPullParser
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Locale

private val Dirt = Color(0xFF29251F)
private val Stone = Color(0xFF393A35)
private val Deep = Color(0xFF171A16)
private val Grass = Color(0xFF55B94B)
private val Gold = Color(0xFFE6C66A)
private val Muted = Color(0xFFB9B9A9)

data class NewsItem(
    val title: String,
    val description: String,
    val link: String,
    val date: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MineNewsApp { url ->
                runCatching {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                }
            }
        }
    }
}

@Composable
fun MineNewsApp(openArticle: (String) -> Unit) {
    var news by remember { mutableStateOf<List<NewsItem>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var refreshedAt by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    suspend fun loadNews() {
        loading = true
        error = null
        try {
            news = withContext(Dispatchers.IO) { fetchBbcNews() }
            refreshedAt = SimpleDateFormat("HH:mm", Locale.getDefault()).format(java.util.Date())
        } catch (e: Exception) {
            error = "Не удалось загрузить новости. Проверь подключение к интернету."
        } finally {
            loading = false
        }
    }

    LaunchedEffect(Unit) { loadNews() }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Deep,
            surface = Stone,
            primary = Grass,
            onPrimary = Color(0xFF10200E),
            onBackground = Color(0xFFF2F0E6),
            onSurface = Color(0xFFF2F0E6)
        )
    ) {
        Column(
            Modifier.fillMaxSize().background(Deep)
        ) {
            Column(
                Modifier.fillMaxWidth()
                    .background(Dirt)
                    .border(width = 0.dp, color = Dirt)
                    .padding(horizontal = 18.dp, vertical = 18.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(46.dp).background(Grass, RoundedCornerShape(8.dp))
                            .border(3.dp, Color(0xFF347B2D), RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("M", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("MINE NEWS", fontSize = 23.sp, fontWeight = FontWeight.Black,
                            letterSpacing = 1.5.sp, fontFamily = FontFamily.Monospace)
                        Text("МИР В КАЖДОМ БЛОКЕ", color = Grass, fontSize = 10.sp,
                            letterSpacing = 1.4.sp, fontWeight = FontWeight.Bold)
                    }
                    IconButton(onClick = { /* refresh is handled below */ }) {
                        Icon(Icons.Default.Language, contentDescription = "Мировые новости", tint = Gold)
                    }
                }
                Spacer(Modifier.height(16.dp))
                Row(
                    Modifier.fillMaxWidth().background(Color(0xFF1D211B), RoundedCornerShape(6.dp))
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(8.dp).background(Grass, RoundedCornerShape(2.dp)))
                    Spacer(Modifier.width(8.dp))
                    Text("МИРОВЫЕ НОВОСТИ", color = Color.White, fontSize = 11.sp,
                        fontWeight = FontWeight.Bold, letterSpacing = 1.sp,
                        fontFamily = FontFamily.Monospace)
                    Spacer(Modifier.weight(1f))
                    Text("BBC • LIVE FEED", color = Muted, fontSize = 9.sp)
                }
            }

            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("Последние события", fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    Text(
                        if (refreshedAt.isNotEmpty()) "Обновлено в $refreshedAt" else "Лента новостей",
                        color = Muted, fontSize = 11.sp
                    )
                }
                Button(
                    onClick = { scope.launch { loadNews() } },
                    colors = ButtonDefaults.buttonColors(containerColor = Grass),
                    shape = RoundedCornerShape(6.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(17.dp))
                    Spacer(Modifier.width(5.dp))
                    Text("ОБНОВИТЬ", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }

            when {
                loading && news.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = Grass)
                        Spacer(Modifier.height(12.dp))
                        Text("ЗАГРУЖАЕМ МИР...", color = Muted, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                    }
                }
                error != null && news.isEmpty() -> Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("⚠", fontSize = 36.sp)
                        Spacer(Modifier.height(12.dp))
                        Text(error!!, color = Muted)
                        Spacer(Modifier.height(16.dp))
                        Button(onClick = { scope.launch { loadNews() } }) {
                            Text("ПОПРОБОВАТЬ СНОВА")
                        }
                    }
                }
                else -> LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(news) { item ->
                        NewsCard(item = item, onClick = { openArticle(item.link) })
                    }
                    item {
                        Text(
                            "Источник: BBC News • RSS. Полные материалы открываются на сайте источника.",
                            color = Muted, fontSize = 10.sp,
                            modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun NewsCard(item: NewsItem, onClick: () -> Unit) {
    Column(
        Modifier.fillMaxWidth().background(Stone, RoundedCornerShape(8.dp))
            .border(2.dp, Color(0xFF55564D), RoundedCornerShape(8.dp))
            .clickable(onClick = onClick).padding(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("BBC NEWS", color = Grass, fontSize = 9.sp, fontWeight = FontWeight.Black,
                letterSpacing = 1.sp, fontFamily = FontFamily.Monospace)
            Spacer(Modifier.weight(1f))
            Text(item.date, color = Muted, fontSize = 9.sp, maxLines = 1)
        }
        Spacer(Modifier.height(9.dp))
        Text(
            item.title,
            color = Color.White,
            fontSize = 16.sp,
            lineHeight = 21.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 3,
            overflow = TextOverflow.Ellipsis
        )
        if (item.description.isNotBlank()) {
            Spacer(Modifier.height(7.dp))
            Text(
                item.description,
                color = Color(0xFFD0D0C5),
                fontSize = 12.sp,
                lineHeight = 17.sp,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis
            )
        }
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("ЧИТАТЬ НОВОСТЬ", color = Gold, fontSize = 10.sp,
                fontWeight = FontWeight.Bold, letterSpacing = 0.7.sp)
            Spacer(Modifier.weight(1f))
            Icon(Icons.Default.OpenInNew, contentDescription = null, tint = Gold, modifier = Modifier.size(15.dp))
        }
    }
}

private fun fetchBbcNews(): List<NewsItem> {
    val connection = URL("https://feeds.bbci.co.uk/news/world/rss.xml").openConnection()
    connection.connectTimeout = 12000
    connection.readTimeout = 12000
    connection.setRequestProperty("User-Agent", "MineNews/1.0 Android")
    connection.getInputStream().use { input ->
        val parser = Xml.newPullParser()
        parser.setInput(input, "UTF-8")
        val result = mutableListOf<NewsItem>()
        var event = parser.eventType
        var insideItem = false
        var tag = ""
        var title = ""
        var description = ""
        var link = ""
        var date = ""

        while (event != XmlPullParser.END_DOCUMENT && result.size < 40) {
            when (event) {
                XmlPullParser.START_TAG -> {
                    tag = parser.name
                    if (tag == "item") {
                        insideItem = true
                        title = ""; description = ""; link = ""; date = ""
                    }
                }
                XmlPullParser.TEXT, XmlPullParser.CDSECT -> {
                    if (insideItem) {
                        val value = parser.text?.trim().orEmpty()
                        when (tag) {
                            "title" -> if (title.isEmpty()) title = value
                            "description" -> if (description.isEmpty()) description = value
                            "link" -> if (link.isEmpty()) link = value
                            "pubDate" -> if (date.isEmpty()) date = value
                        }
                    }
                }
                XmlPullParser.END_TAG -> {
                    if (parser.name == "item") {
                        if (title.isNotBlank() && link.startsWith("http")) {
                            result.add(NewsItem(title, android.text.Html.fromHtml(description, android.text.Html.FROM_HTML_MODE_LEGACY).toString(), link, date))
                        }
                        insideItem = false
                    }
                    tag = ""
                }
            }
            event = parser.next()
        }
        if (result.isEmpty()) throw IllegalStateException("RSS feed is empty")
        return result
    }
}
